find_delays
===========

.. autofunction:: find_delay.find_delay.find_delays
