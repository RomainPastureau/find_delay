from setuptools import setup, find_packages

setup(name='find_delay', version='2.15', packages=find_packages())