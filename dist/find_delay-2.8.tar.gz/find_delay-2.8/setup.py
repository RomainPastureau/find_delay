from setuptools import setup, find_packages

setup(name='find_delay', version='2.8', packages=find_packages())