find_delay
==========

.. autofunction:: find_delay.find_delay
