Private functions
=================

.. autofunction:: find_delay.find_delay._filter_frequencies
.. autofunction:: find_delay.find_delay._get_number_of_windows
.. autofunction:: find_delay.find_delay._get_envelope
.. autofunction:: find_delay.find_delay._resample_window
.. autofunction:: find_delay.find_delay._resample
.. autofunction:: find_delay.find_delay._convert_to_mono
.. autofunction:: find_delay.find_delay._create_figure
