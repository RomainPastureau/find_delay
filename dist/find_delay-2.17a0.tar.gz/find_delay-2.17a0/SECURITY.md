# Security Policy

## Supported Versions

| Version | Supported          |
|---------| ------------------ |
| 2.17a   | :white_check_mark: |

## Reporting a Vulnerability

To report a vulnerability, please [open an issue on GitHub](https://github.com/RomainPastureau/find_delay/security/advisories/new).