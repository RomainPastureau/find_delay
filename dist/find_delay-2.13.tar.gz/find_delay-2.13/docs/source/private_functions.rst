Private functions
=================

.. autofunction:: find_delay.private_functions._filter_frequencies
.. autofunction:: find_delay.private_functions._get_number_of_windows
.. autofunction:: find_delay.private_functions._get_envelope
.. autofunction:: find_delay.private_functions._resample_window
.. autofunction:: find_delay.private_functions._resample
.. autofunction:: find_delay.private_functions._cross_correlation
.. autofunction:: find_delay.private_functions._convert_to_mono
.. autofunction:: find_delay.private_functions._create_figure
