from setuptools import setup, find_packages

setup(name='find_delay', version='2.14', packages=find_packages())